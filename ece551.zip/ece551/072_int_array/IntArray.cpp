#include "IntArray.h"

#include <assert.h>

#include <ostream>

IntArray::IntArray() {
  numElements = 0;
  data = NULL;
}
IntArray::IntArray(int n) {
  if (n < 0) {
    exit(EXIT_FAILURE);
  }
  if (n == 0) {
    numElements = 0;
    data = NULL;
  }
  numElements = n;
  data = new int[n];
  for (int i = 0; i < n; i++) {
    data[i] = 0;
  }
}

IntArray::IntArray(const IntArray & rhs) {
  numElements = rhs.numElements;
  data = new int[rhs.numElements];
  for (int i = 0; i < rhs.numElements; i++) {
    data[i] = rhs.data[i];
  }
}
IntArray::~IntArray() {
  delete[] data;
}

IntArray & IntArray::operator=(const IntArray & rhs) {
  if (this != &rhs) {
    int * temp = new int[rhs.numElements];
    for (int i = 0; i < rhs.numElements; i++) {
      temp[i] = rhs.data[i];
    }
    delete[] data;
    numElements = rhs.numElements;
    data = temp;
  }
  return *this;
}

const int & IntArray::operator[](int index) const {
  assert(index < numElements && index >= 0);
  return data[index];
}
int & IntArray::operator[](int index) {
  assert(index < numElements && index >= 0);
  return data[index];
}

int IntArray::size() const {
  if (this->numElements < 0) {
    exit(EXIT_FAILURE);
  }
  return numElements;
}

bool IntArray::operator==(const IntArray & rhs) const {
  if (this->numElements == 0 && rhs.numElements == 0) {
    return true;
  }
  int i = 0;
  if (this->numElements != rhs.numElements) {
    return false;
  }
  while (i < rhs.numElements) {
    if (this->data[i] != rhs.data[i]) {
      return false;
    }
    i++;
  }
  return true;
}

bool IntArray::operator!=(const IntArray & rhs) const {
  int i = 0;
  if (this->numElements != rhs.numElements) {
    return true;
  }
  while (i < rhs.numElements) {
    if (this->data[i] != rhs.data[i]) {
      return true;
    }
    i++;
  }
  return false;
}

std::ostream & operator<<(std::ostream & s, const IntArray & rhs) {
  if (rhs.size() == 0) {
    s << "{"
      << "}";
    return s;
  }
  s << "{";
  for (int i = 0; i < rhs.size() - 1; i++) {
    s << rhs.operator[](i) << ", ";
  }
  s << rhs.operator[](rhs.size() - 1) << "}";
  return s;
}
