#include <stdio.h>
#include <stdlib.h>
struct retire_info_tag {
  int months;
  double contribution;
  double rate_of_return;
};
typedef struct retire_info_tag retire_info_t;
double balance(double initial, retire_info_t info) {
  return initial * (1 + info.rate_of_return) + info.contribution;
}

void retirement(int startAge, double initial, retire_info_t working, retire_info_t retired) {
  double sum = initial;
  int age;
  int age_y, age_month;
  for (age = startAge; age < startAge + working.months; age++) {
    age_y = age / 12;
    age_month = age % 12;
    printf("Age %3d month %2d you have $%.2lf\n", age_y, age_month, sum);
    sum = balance(sum, working);
  }
  for (age = startAge + working.months; age < startAge + working.months + retired.months; age++) {
    age_y = age / 12;
    age_month = age % 12;
    printf("Age %3d month %2d you have $%.2lf\n", age_y, age_month, sum);
    sum = balance(sum, retired);
  }
}
int main() {
  retire_info_t working;
  retire_info_t retired;
  working.months = 489;
  working.contribution = 1000;
  working.rate_of_return = 0.045 / 12;
  retired.months = 384;
  retired.contribution = -4000;
  retired.rate_of_return = 0.01 / 12;
  retirement(327, 21345, working, retired);
  return EXIT_SUCCESS;
}
