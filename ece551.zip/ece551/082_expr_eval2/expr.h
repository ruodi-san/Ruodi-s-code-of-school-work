#include <iostream>
#include <sstream>
#include <string>
using namespace std;
class Expression
{
 protected:
  string ans;

 public:
  virtual std::string toString() const = 0;
  virtual ~Expression() {}
};
class NumExpression : public Expression
{
 private:
  long num;

 public:
  NumExpression(long input) : num(input) {
    stringstream ss;
    ss << num;
    ans = ss.str();
  }

  virtual std::string toString() const { return ans; }

  virtual ~NumExpression() {}
};
class PlusExpression : public Expression
{
 private:
  string alhs;
  string arhs;

 public:
  PlusExpression(Expression * lhs, Expression * rhs) {
    alhs = "(" + lhs->toString();
    arhs = rhs->toString() + ")";
    ans = alhs + "+" + arhs;
    delete lhs;
    delete rhs;
  }
  std::string toString() const { return ans; }
  virtual ~PlusExpression() {}
};

class operators : public Expression
{
 protected:
  string alhs;
  string arhs;

 public:
  operators(Expression * lhs, Expression * rhs) :
      alhs("(" + lhs->toString()),
      arhs(rhs->toString() + ")") {
    delete lhs;
    delete rhs;
  }
  virtual string toString() const { return ans; }
  virtual ~operators() {}
};

class MinusExpression : public operators
{
 public:
  MinusExpression(Expression * lhs, Expression * rhs) : operators(lhs, rhs) {
    ans = alhs + "-" + arhs;
  }
  virtual ~MinusExpression() {}
};

class TimesExpression : public operators
{
 public:
  TimesExpression(Expression * lhs, Expression * rhs) : operators(lhs, rhs) {
    ans = alhs + "*" + arhs;
  }
  virtual ~TimesExpression() {}
};
class DivExpression : public operators
{
 public:
  DivExpression(Expression * lhs, Expression * rhs) : operators(lhs, rhs) {
    ans = alhs + "/" + arhs;
  }
  virtual ~DivExpression() {}
};
