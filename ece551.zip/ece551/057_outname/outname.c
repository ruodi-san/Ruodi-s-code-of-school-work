#include "outname.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char * computeOutputFileName(const char * inputName) {
  /* FILE * f = fopen(inputName, "r");
  if (f == NULL) {
    perror("Could not open file");
    exit(EXIT_FAILURE);
  }
  //outfileNAme is inputName + ".counts", so add 5 to its length.
  char * outFileName = malloc((strlen(inputName) + 8) * sizeof(*outFileName));
  strcpy(outFileName, inputName);
  strcat(outFileName, ".counts");
   FILE * outFile = fopen(outFileName, "w");

  free(outFileName);

  if (fclose(outFile) != 0) {
    perror("Failed to close the input file!");
    exit(EXIT_FAILURE);
  }
  if (fclose(f) != 0) {
    perror("Failed to close the input file!");
    exit(EXIT_FAILURE);
    }*/
  if (inputName == NULL) {
    fprintf(stderr, "no inputname!");
    exit(EXIT_FAILURE);
  }
  char * outputName = malloc((strlen(inputName) + 8) * sizeof(*outputName));

  strcpy(outputName, inputName);

  strcat(outputName, ".counts");
  return outputName;
}  //WRITE ME
