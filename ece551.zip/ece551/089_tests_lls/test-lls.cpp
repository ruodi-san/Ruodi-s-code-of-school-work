#include <assert.h>

#include <cstdlib>

#include "il.h"

void testList(void) {
  IntList a;
  /* if (a.head != NULL || a.tail != NULL || a.getSize() != 0) {
    exit(EXIT_FAILURE);
  }*/
  assert(a.head == NULL && a.tail == NULL && a.size == 0);
  /* IntList c(a);

  if (c.getSize() != 0 || (c.head != NULL || c.tail != NULL)) {
    exit(EXIT_FAILURE);
    }*/
  a.addFront(3);
  assert(a.getSize() == 1);
  assert(a.size == 1);
  a.addBack(4);
  assert(a.getSize() == 2);
  assert(a.size == 2);
  a.addFront(5);
  assert(a[0] == 5 && a[1] == 3 && a[2] == 4);
  IntList b;
  b = a;
  assert(b.head != a.head && b.tail != a.tail);
  assert(b.size == a.size);
  IntList c(a);
  assert(b.head != a.head && b.tail != a.tail);
  assert(b.size == a.size);
  assert(a.find(2) == -1);
  a.addBack(6);
  a.remove(3);
  assert(a.size == 3);
  assert(a.head->next->data == 4);

  assert(a.head->next->prev->data == 5);

  a.remove(5);
  assert(a.head->data == 4);
  a.remove(6);
  assert(a.tail->data == 4);
}

int main(void) {
  testList();

  return EXIT_SUCCESS;
}
