#include "kv.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

kvarray_t * readKVs(const char * fname) {
  kvarray_t * list = malloc(sizeof(*list));
  list->nums = 0;
  list->array = malloc((list->nums + 1) * (sizeof(*(list->array))));

  // list->array->key = NULL;
  // list->array->value = NULL;
  // list->array->key = malloc(sizeof(*list->array->key));
  //  list->array->value = malloc(sizeof(*list->array->value));
  FILE * f = fopen(fname, "r");
  if (f == NULL) {
    fprintf(stdout, "could not open file");
    exit(EXIT_FAILURE);
  }
  char * lines = NULL;
  size_t sz;

  while (getline(&lines, &sz, f) >= 0) {
    size_t ikey = 0;
    size_t ivalue = 0;
    list->array[list->nums].key = NULL;
    list->array[list->nums].value = NULL;
    while (lines[ikey] != '=') {
      list->array[list->nums].key =
          realloc(list->array[list->nums].key, (ikey + 1) * sizeof(*(list->array[list->nums].key)));
      list->array[list->nums].key[ikey] = lines[ikey];
      ikey++;
    }
    list->array[list->nums].key =
        realloc(list->array[list->nums].key, (ikey + 1) * sizeof(*(list->array[list->nums].key)));
    list->array[list->nums].key[ikey] = '\0';

    size_t j = ikey + 1;
    while ((lines[j] != '\0') && (lines[j] != '\n')) {
      list->array[list->nums].value = realloc(
          list->array[list->nums].value, (ivalue + 1) * sizeof(*(list->array[list->nums].value)));
      list->array[list->nums].value[ivalue] = lines[j];
      j++;
      ivalue++;
    }
    list->array[list->nums].value = realloc(
        list->array[list->nums].value, (ivalue + 1) * sizeof(*(list->array[list->nums].value)));
    list->array[list->nums].value[ivalue] = '\0';
    //   list->array[list->nums].key = NULL;
    // list->array[list->nums].value = NULL;

    list->nums++;
    list->array = realloc(list->array, (list->nums + 1) * (sizeof(*(list->array))));
    // free(lines);
    lines = NULL;
  }
  free(lines);
  /* if (list->array == NULL) {
    fprintf(stderr, "invalid input");
    free(list->array);
    return NULL;
  }
*/
  if (fclose(f) != 0) {
    fprintf(stderr, "could not close file");
    return NULL;
  }
  return list;
}

void freeKVs(kvarray_t * pairs) {
  for (int i = 0; i < pairs->nums; i++) {
    free(pairs->array[i].key);  //WRITE ME
    free(pairs->array[i].value);
  }
  free(pairs->array);
  free(pairs);
}
void printKVs(kvarray_t * pairs) {
  for (int i = 0; i < pairs->nums; i++) {
    fprintf(stdout,
            "key = '%s' value = '%s'\n",
            pairs->array[i].key,
            pairs->array[i].value);  //WRITE ME
  }
}
char * lookupValue(kvarray_t * pairs, const char * key) {
  for (int i = 0; i < pairs->nums; i++) {
    if ((strcmp(key, pairs->array[i].key)) == 0) {
      return pairs->array[i].value;  //WRITE ME
    }
  }
  return NULL;
}
