#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>

#include "function.h"
using namespace std;

class CountedIntFn : public Function<int, int>
{
 protected:
  unsigned remaining;
  Function<int, int> * f;
  const char * mesg;

 public:
  CountedIntFn(unsigned n, Function<int, int> * fn, const char * m) :
      remaining(n),
      f(fn),
      mesg(m) {}
  virtual int invoke(int arg) {
    if (remaining == 0) {
      fprintf(stderr, "Too many function invocations in %s\n", mesg);
      exit(EXIT_FAILURE);
    }
    remaining--;
    return f->invoke(arg);
  }
};
class Intfunction : public Function<int, int>
{
 public:
  virtual int invoke(int arg) { return 10 * arg + 5; }
};
class Minustwo : public Function<int, int>
{
 public:
  virtual int invoke(int arg) { return arg - 2; }
};
class Sin : public Function<int, int>
{
 public:
  virtual int invoke(int arg) { return 1000000 * (sin(arg / 100000.0) - 0.5); }
};

int binarySearchForZero(Function<int, int> * f, int low, int high);

void check(Function<int, int> * f, int low, int high, int expected_ans, const char * mesg) {
  int num = 1;
  if (high > low) {
    num = log2(high - low) + 1;
    CountedIntFn * cf = new CountedIntFn(num, f, mesg);
    if (binarySearchForZero(cf, low, high) != expected_ans) {
      fprintf(stderr, " answer not correct in the part of  %s\n", mesg);
      exit(EXIT_FAILURE);
    }
    delete cf;
  }
}

int main() {
  Minustwo * f = new Minustwo();
  Sin * f2 = new Sin();
  Intfunction * f3 = new Intfunction();
  const char * s1 = "all positive ints";
  const char * s2 = "all negtive ints";
  const char * s3 = "part positive and part negtive ints";
  check(f, 1, 100, 2, s1);
  check(f, -10, 0, -1, s2);
  check(f, -10, 10, 2, s3);
  check(f, -2, -2, -3, s2);
  check(f3, -3, 2, -1, s1);
  check(f2, 0, 150000, 52359, s1);
  return EXIT_SUCCESS;
}
