#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char ** argv) {
  if (argc != 2) {
    fprintf(stderr, "Usage: encrypt key inputFileName\n");
    return EXIT_FAILURE;
  }

  FILE * f = fopen(argv[1], "r");
  if (argv[1] == NULL) {
    return EXIT_FAILURE;
  }
  if (f == NULL) {
    perror("Could not open file");
    return EXIT_FAILURE;
  }
  char matrix[11][12];
  int i = 0;
  while ((fgets(matrix[i], 12, f)) != NULL) {
    if (strchr(matrix[i], '\n') != &matrix[i][10]) {
      fprintf(stderr, "Invalid input");
      return EXIT_FAILURE;
    }
    if (i == 10) {
      fprintf(stderr, "Invalid lineinput");
      return EXIT_FAILURE;
    }

    if ((strchr(matrix[i], '\n')) - matrix[i] < 10) {
      fprintf(stderr, "Invalid input with short lines \n");
      return EXIT_FAILURE;
    }
    i += 1;  //        printf("%c", matrix[i][j]);
  }
  if (i != 10) {
    fprintf(stderr, "Invalid lineinput");
    return EXIT_FAILURE;
  }

  char r[10][10];
  for (int a = 0; a < 10; a++) {
    for (int b = 0; b < 10; b++) {
      r[b][9 - a] = matrix[a][b];
      //  printf("%c", r[b][9 - a]);
      //  printf("%c", matrix[a][b]);
    }
  }
  for (int a = 0; a < 10; a++) {
    for (int b = 0; b < 10; b++) {
      printf("%c", r[a][b]);
    }
    printf("\n");
  }

  if (fclose(f) != 0) {
    perror("Failed to close the input file!");

    return EXIT_FAILURE;
  }
  return EXIT_SUCCESS;
}
