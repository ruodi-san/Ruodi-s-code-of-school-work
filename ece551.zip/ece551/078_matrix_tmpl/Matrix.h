#ifndef __T_MATRIX_H___
#define __T_MATRIX_H___

#include <assert.h>

#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
template<typename T>
class Matrix
{
 private:
  int numRows;
  int numColumns;
  vector<vector<T> > rows;

 public:
  Matrix() : numRows(0), numColumns(0) {}
  Matrix(int r, int c) : numRows(r), numColumns(c), rows(numRows) {
    if (r < 0 || c < 0) {
      exit(EXIT_FAILURE);
    }
    for (int i = 0; i < numRows; i++) {
      rows[i].resize(numColumns);
    }
  }
  Matrix(const Matrix & rhs) : numRows(rhs.numRows), numColumns(rhs.numColumns), rows(rhs.rows) {}

  ~Matrix() {}
  Matrix & operator=(const Matrix & rhs) {
    if (this == &rhs) {
      return *this;
    }

    numColumns = rhs.numColumns;
    numRows = rhs.numRows;
    this->~Matrix();
    rows = rhs.rows;
    return *this;
  }
  int getRows() const { return this->numRows; }
  int getColumns() const { return this->numColumns; }
  const vector<T> & operator[](int index) const {
    assert(index >= 0 && index < numRows);
    return rows[index];
  }
  vector<T> & operator[](int index) {
    assert(index >= 0 && index < numRows);
    return rows[index];
  }
  bool operator==(const Matrix & rhs) const {
    if (numRows == 0 && rhs.numRows == 0) {
      return true;
    }
    if (numRows != rhs.numRows) {
      return false;
    }
    if (numColumns != rhs.numColumns) {
      return false;
    }

    if (rows != rhs.rows) {
      return false;
    }
    return true;
  }

  Matrix operator+(const Matrix & rhs) const {
    assert(numRows == rhs.numRows);
    assert(numColumns == rhs.numColumns);
    if (numRows < 0 || numColumns < 0) {
      exit(EXIT_FAILURE);
    }

    Matrix a(numRows, numColumns);
    for (int i = 0; i < numRows; i++) {
      for (int j = 0; j < numColumns; j++) {
        a[i][j] = (*this)[i][j] + rhs[i][j];
      }
    }
    return a;
  }

  friend std::ostream & operator<<(std::ostream & s, const Matrix & rhs) {
    if (rhs.numRows == 0) {
      s << "[ ]";
      return s;
    }
    s << "[ ";
    for (int i = 0; i < rhs.numRows; i++) {
      s << "{";
      for (int j = 0; j < rhs.numColumns - 1; j++) {
        s << rhs[i][j] << ",";
      }
      s << rhs[i][rhs.numColumns - 1] << "}";
      if (i != rhs.numRows - 1) {
        s << ",\n";
      }
      else {
        s << " ]";
      }
    }

    return s;
  }
};
#endif
