#include <cstdlib>
#include <iostream>
#include <string>

#include "bstmap.h"
#include "map.h"

using namespace std;

int main() {
  BstMap<int, int> map;
  map.add(2, 2);
  map.printtest();
  map.add(4, 44);
  map.printtest();
  map.add(70, 77);
  map.printtest();
  map.add(6, 5);
  map.printtest();
  map.remove(2);
  map.printtest();
  cout << map.lookup(4) << endl;
  map.remove(4);
  map.printtest();
  map.remove(-1);
  map.printtest();
  cout << map.lookup(4) << endl;
  cout << map.lookup(6) << endl;

  return EXIT_SUCCESS;
}
