

#include "counts.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
counts_t * createCounts(void) {
  counts_t * out;

  out = malloc(sizeof(*out));
  out->size = 0;
  out->size_u = 0;
  out->vn = NULL;  //malloc(((out->size) + 1) * sizeof(*(out->vn)));
  return out;
}
void addCount(counts_t * c, const char * name) {
  if (c == NULL) {
    fprintf(stderr, "no input");
    exit(EXIT_FAILURE);
  }
  if (name == NULL) {
    c->size_u++;
    return;
  }
  int j = 0;
  for (int i = 0; i < c->size; i++) {
    if (strcmp(name, c->vn[i].vl) == 0) {
      c->vn[i].n++;
      j++;
    }
  }
  if (j == 0) {
    c->size++;
    c->vn = realloc(c->vn, c->size * sizeof(*(c->vn)));
    c->vn[c->size - 1].vl = NULL;
    c->vn[c->size - 1].n = 1;

    int k = 0;
    while (name[k] != '\0') {
      c->vn[c->size - 1].vl = realloc(c->vn[c->size - 1].vl, (k + 1) * sizeof((*c->vn)));
      c->vn[c->size - 1].vl[k] = name[k];
      k++;
    }
    c->vn[c->size - 1].vl = realloc(c->vn[c->size - 1].vl, (k + 1) * sizeof(*(c->vn)));
    c->vn[c->size - 1].vl[k] = '\0';
  }
}

void printCounts(counts_t * c, FILE * outFile) {
  if (c == NULL) {
    fprintf(stderr, "no valid input c");
    exit(EXIT_FAILURE);
  }
  if ((c->size == 0) && (c->size_u == 0)) {
    fprintf(stderr, "no input c");
    exit(EXIT_FAILURE);
  }
  /*  if (c->size == 0) {
    fprintf(outFile, "<unknown>:%d", c->size_u);
    return;
    }*/
  for (int i = 0; i < c->size; i++) {
    fprintf(outFile, "%s: %d\n", c->vn[i].vl, c->vn[i].n);
  }
  if (c->size_u != 0) {
    fprintf(outFile, "<unknown> : %d", c->size_u);
  }
}

void freeCounts(counts_t * c) {
  for (int i = 0; i < c->size; i++) {
    free(c->vn[i].vl);
  }
  free(c->vn);
  free(c);  //WRITE ME
}
