#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "counts.h"
#include "kv.h"
#include "outname.h"

counts_t * countFile(const char * filename, kvarray_t * kvPairs) {
  /* counts_t * out = malloc(sizeof(*out));
  out->size = 0;
  out->size_u = 0;
  out->vn = NULL;
   int nums = 0;
  int len = strlen(filename);
  for (int i = 0; i < len; i++) {
    if (filename[i] == '\n') {
      nums++;
    }
  }
  int j = 0;
  int a = 0;
  char ** input = malloc(nums * sizeof(**input));
  for (int k = 0; k < nums; k++) {
    while (filename[j] != '\n' && filename[j] != '\0') {
      input[k][a] = filename[j];
      a++;
      j++;
    }
    input[k][a] = '\0';
    a = 0;
    j++;
  }
  int x = 0;
  for (int i = 0; i < nums; i++) {
    for (int j = 0; j < kvPairs->nums; j++) {
      if (strcmp(kvPairs->array[j].key, input[i]) == 0) {
        //  out->size++;
        // out->vn[out->size - 1].vl = kvPairs->array[j].value;
        // out->vn[out->size - 1].n++;
        input[i] = kvPairs->array[j].value;
        x++;
      }
    }
    if (x == 0) {
      // out->size_u++;
      input[i] = NULL;
    }
    }*/
  FILE * f = fopen(filename, "r");
  if (f == NULL) {
    fprintf(stderr, "no file input");
    exit(EXIT_FAILURE);
  }
  char ** input = NULL;
  char * line = NULL;
  size_t sz;  // = 0;
  size_t k = 0;
  while ((getline(&line, &sz, f)) >= 0) {
    input = realloc(input, (k + 1) * sizeof(*input));
    input[k] = line;
    line = NULL;
    k++;
  }
  free(line);
  char ** trans = NULL;
  for (size_t i = 0; i < k; i++) {
    size_t ii = 0;
    while (input[i][ii] != '\n') {
      ii++;
    }
    input[i][ii] = '\0';
    trans = realloc(trans, (i + 1) * sizeof(*trans));
    trans[i] = lookupValue(kvPairs, input[i]);
    free(input[i]);
  }
  free(input);
  counts_t * out = createCounts();
  for (size_t i = 0; i < k; i++) {
    addCount(out, trans[i]);
  }
  if (fclose(f) != 0) {
    fprintf(stderr, "could not close file");
    exit(EXIT_FAILURE);
  }
  free(trans);
  return out;
}
int main(int argc, char ** argv) {
  if (argc < 2) {
    fprintf(stderr, "invalid input format!");
    exit(EXIT_FAILURE);
  }
  kvarray_t * kvPairs = readKVs(argv[1]);
  for (int i = 2; i < argc; i++) {
    counts_t * c = countFile(argv[i], kvPairs);
    char * outName = computeOutputFileName(argv[i]);
    FILE * f = fopen(outName, "w");
    printCounts(c, f);
    if (fclose(f) != 0) {
      fprintf(stderr, "could not close files");
      exit(EXIT_FAILURE);
    }
    free(outName);
    freeCounts(c);
  }
  freeKVs(kvPairs);
  return EXIT_SUCCESS;
}

//WRITE ME (plus add appropriate error checking!)
//read the key/value pairs from the file named by argv[1] (call the result kv)

//count from 2 to argc (call the number you count i)

//count the values that appear in the file named by argv[i], using kv as the key/value pair
//   (call this result c)

//compute the output file name from argv[i] (call this outName)

//open the file named by outName (call that f)

//print the counts from c into the FILE f

//close f

//free the memory for outName and c

//free the memory for kv
