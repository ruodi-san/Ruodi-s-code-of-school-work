#include <stdio.h>
#include <stdlib.h>
unsigned power(unsigned x, unsigned y);

int main() {
  if (power(0, 0) != 1) {
    exit(EXIT_FAILURE);
  }
  if (power(0, 1) != 0) {
    exit(EXIT_FAILURE);
  }
  if (power(1, 0) != 1) {
    exit(EXIT_FAILURE);
  }
  if (power(2, 3) != 8) {
    exit(EXIT_FAILURE);
  }
  if (power(1, 5) != 1) {
    exit(EXIT_FAILURE);
  }
  if (power(5, 1) != 5) {
    exit(EXIT_FAILURE);
  }
  if (power(32767, 1) != 32767) {
    exit(EXIT_FAILURE);
  }
  if (power(2, 31) != 2147483648) {
    exit(EXIT_FAILURE);
  }

  else {
    return EXIT_SUCCESS;
  }
}
