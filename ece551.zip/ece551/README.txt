Welcome to your ece551 git repository.

The first thing you should do is 

  git pull

Once you have done that, you will see your intial assignment. 
As you complete assignments, more will be released.

You should start with 000_submit, which will help you
familiarize yourself with git, view-grades, and grade.
