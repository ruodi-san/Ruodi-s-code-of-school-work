#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>
using namespace std;
template<typename string>

std::ostream & operator<<(std::ostream & s, std::vector<string> & v) {
  for (size_t i = 0; i < v.size(); i++) {
    s << v[i] << "\n";
  }
  return s;
}
int main(int argc, char ** argv) {
  if (argc < 0) {
    exit(EXIT_FAILURE);
  }
  if (argc == 1) {
    std::vector<string> line;
    string v1;
    while (std::cin.eof() != 1) {
      getline(std::cin, v1);
      line.push_back(v1);
    }
    sort(line.begin(), line.end());
    std::cout << line << std::endl;
    return EXIT_SUCCESS;
  }
  if (argc >= 2) {
    for (int i = 1; i < argc; i++) {
      ifstream file;
      std::vector<string> lines;
      string v2;
      file.open(argv[i]);
      if (!file == 1) {
        cerr << "could not open file";
        exit(EXIT_FAILURE);
      }
      while (file.eof() != 1) {
        getline(file, v2);
        lines.push_back(v2);
      }
      file.close();
      sort(lines.begin(), lines.end());
      std::cout << lines << std::endl;
    }
    return EXIT_SUCCESS;
  }
}
