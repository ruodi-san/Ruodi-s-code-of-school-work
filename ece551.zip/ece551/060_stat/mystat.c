#include <ctype.h>
#include <grp.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
//This function is for Step 4
char * time2str(const time_t * when, long ns) {
  char * ans = malloc(128 * sizeof(*ans));
  char temp1[64];
  char temp2[32];
  const struct tm * t = localtime(when);
  strftime(temp1, 512, "%Y-%m-%d %H:%M:%S", t);
  strftime(temp2, 32, "%z", t);
  snprintf(ans, 128, "%s.%09ld %s", temp1, ns, temp2);
  return ans;
}
void printname(char * file, struct stat st) {
  if (S_ISLNK(st.st_mode)) {
    char linktarget[256];
    ssize_t len = readlink(file, linktarget, 256);
    if (len < 0) {
      fprintf(stderr, "len should be positive");
    }
    if (len < 255) {
      linktarget[len] = '\0';
    }
    else {
      linktarget[255] = '\0';
    }
    printf("  File: %s -> %s\n", file, linktarget);
  }
  else {
    printf("  File: %s\n", file);
  }
}
void getmode(struct stat st) {
  char * mode = NULL;
  switch (st.st_mode & S_IFMT) {
    case S_IFBLK:
      mode = "block special file";
      break;
    case S_IFCHR:
      mode = "character special file";
      break;
    case S_IFDIR:
      mode = "directory";
      break;
    case S_IFIFO:
      mode = "fifo";
      break;
    case S_IFLNK:
      mode = "symbolic link";
      break;
    case S_IFREG:
      mode = "regular file";
      break;
    case S_IFSOCK:
      mode = "socket";
      break;
    default:
      mode = "unknown?";
      break;
  }

  printf("  Size: %-10lu\tBlocks: %-10lu IO Block: %-6lu %s\n",
         (long unsigned)st.st_size,
         (long unsigned)st.st_blocks,
         (long unsigned)st.st_blksize,
         mode);
  if (S_ISCHR(st.st_mode) || S_ISBLK(st.st_mode)) {
    printf("Device: %lxh/%lud\tInode: %-10lu  Links: %-5lu Device type: %d,%d\n",
           (long)(st.st_dev),
           (long)(st.st_dev),
           (long unsigned)st.st_ino,
           (long unsigned)st.st_nlink,
           major(st.st_rdev),
           minor(st.st_rdev));
  }
  else {
    printf("Device: %lxh/%lud\tInode: %-10lu  Links: %lu\n",
           (long)(st.st_dev),
           (long)(st.st_dev),
           (long unsigned)st.st_ino,
           (long unsigned)st.st_nlink);
  }
}
void getaccess(char * file) {
  FILE * f = fopen(file, "r");
  if (f == NULL) {
    fprintf(stderr, "INvalid input");
    exit(EXIT_FAILURE);
  }
  struct stat st;
  if (lstat(file, &st) == -1) {
    perror("wrong input");
    exit(EXIT_FAILURE);
  }
  printname(file, st);
  getmode(st);
  char ac[11] = {0};
  switch ((st.st_mode) & S_IFMT) {
    case S_IFBLK: {
      ac[0] = 'b';
      break;
    }
    case S_IFCHR: {
      ac[0] = 'c';
      break;
    }
    case S_IFDIR: {
      ac[0] = 'd';
      break;
    }
    case S_IFIFO: {
      ac[0] = 'p';
      break;
    }
    case S_IFLNK: {
      ac[0] = 'l';
      break;
    }
    case S_IFREG: {
      ac[0] = '-';
      break;
    }
    case S_IFSOCK: {
      ac[0] = 's';
      break;
    }
  }
  ac[1] = ((st.st_mode & S_IRUSR) != 0) ? 'r' : '-';
  ac[2] = ((st.st_mode & S_IWUSR) != 0) ? 'w' : '-';
  ac[3] = ((st.st_mode & S_IXUSR) != 0) ? 'x' : '-';
  ac[4] = ((st.st_mode & S_IRGRP) != 0) ? 'r' : '-';
  ac[5] = ((st.st_mode & S_IWGRP) != 0) ? 'w' : '-';
  ac[6] = ((st.st_mode & S_IXGRP) != 0) ? 'x' : '-';
  ac[7] = ((st.st_mode & S_IROTH) != 0) ? 'r' : '-';
  ac[8] = ((st.st_mode & S_IWOTH) != 0) ? 'w' : '-';
  ac[9] = ((st.st_mode & S_IXOTH) != 0) ? 'x' : '-';
  ac[10] = '\0';
  struct passwd * uid = getpwuid(st.st_uid);
  struct group * gid = getgrgid(st.st_gid);
  printf("Access: (%04o/%s)  Uid: (%5d/%8s)   Gid: (%5d/%8s)\n",
         (st.st_mode & ~S_IFMT),
         ac,
         st.st_uid,
         uid->pw_name,
         st.st_gid,
         gid->gr_name);
  char * atimestr = time2str(&st.st_atime, st.st_atim.tv_nsec);
  printf("Access: %s\n", atimestr);
  free(atimestr);
  char * mtimestr = time2str(&st.st_mtime, st.st_mtim.tv_nsec);
  printf("Modify: %s\n", mtimestr);
  free(mtimestr);
  char * ctimestr = time2str(&st.st_ctime, st.st_ctim.tv_nsec);
  printf("Change: %s\n", ctimestr);
  free(ctimestr);
  printf(" Birth: -\n");
  if (fclose(f) != 0) {
    fprintf(stderr, "couldn't close file");
    exit(EXIT_FAILURE);
  }
}
int main(int argc, char ** argv) {
  if (argc < 2) {
    fprintf(stderr, "wrong type");
    exit(EXIT_FAILURE);
  }

  for (int count = 1; count < argc; count++) {
    if (argv[count] == NULL) {
      fprintf(stderr, "invalid input");
      exit(EXIT_FAILURE);
    }
    getaccess(argv[count]);
  }

  return (EXIT_SUCCESS);
}
