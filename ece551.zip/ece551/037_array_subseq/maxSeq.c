#include <stdio.h>
#include <stdlib.h>
size_t maxSeq(int * array, size_t n) {
  size_t sum = 1;
  size_t summax = 1;
  int * p = &array[0];
  if (n == 0) {
    return 0;
  }
  if (n == 1) {
    return 1;
  }

  for (size_t i = 0; i < n - 1; i++, p++) {
    if (*(p + 1) <= *p) {
      if (sum > summax)
        summax = sum;
      sum = 1;
    }
    else {
      sum += 1;
    }
  }
  if (sum > summax) {
    summax = sum;
  }
  return summax;
}
