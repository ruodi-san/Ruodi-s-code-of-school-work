#include <stdio.h>
#include <stdlib.h>
size_t maxSeq(int * array, size_t n) {
  if (n <= 0) {
    return 0;
  }
  else {
    int * sum;
    sum = 0;
    size_t j = 0;
    size_t i = 0;
    while (i < n && j < n) {
      if (array[j + 1] > array[j]) {
        sum[i] += 1;
        j += 1;
      }
      else {
        i += 1;
      }
    }
    size_t summax = 0;
    for (i = 1; i < n; i++) {
      if (sum[i] > sum[summax]) {
        summax = i;
      }
      return sum[summax];
    }
  }
}
