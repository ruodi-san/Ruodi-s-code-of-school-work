#include <stdio.h>
#include <stdlib.h>
size_t maxSeq(int * array, size_t n);
int main() {
  int a[] = {1, 2, 4, 6, 4, 5};
  int b[] = {2, 1, 4, 7, 9, 10, 1};
  int c[] = {4, 3, 6, 8, 10, 12, 14, 0, 4, 6, 9, 17};
  // int d[] = {};
  int e[] = {0, 0, 0};
  int f[] = {9, 7, 4};
  int g[] = {-1, 2, 6, -4};

  int h[] = {-4, -1, 6, 2, 4, 8};
  int i[] = {-2, 0, 1, 3};
  if (maxSeq(a, 6) != 4 || maxSeq(b, 7) != 5 || maxSeq(c, 12) != 6 || maxSeq(NULL, 0) != 0 ||
      maxSeq(e, 3) != 1 || maxSeq(f, 3) != 1 || maxSeq(g, 4) != 3 || maxSeq(h, 6) != 3 ||
      maxSeq(i, 4) != 4) {
    return EXIT_FAILURE;
  }
  else
    return EXIT_SUCCESS;
}
