#include "IntMatrix.h"

#include "IntArray.h"
IntMatrix::IntMatrix() {
  this->numColumns = 0;
  this->numRows = 0;
  this->rows = NULL;
}
IntMatrix::IntMatrix(int r, int c) {
  if (r < 0 || c < 0) {
    exit(EXIT_FAILURE);
  }
  if (r == 0) {
    numRows = 0;
    numColumns = c;
    rows = NULL;
  }
  else {
    this->numColumns = c;
    this->numRows = r;
    rows = new IntArray *[r];
    for (int i = 0; i < r; i++) {
      rows[i] = new IntArray(c);
    }
  }
}
IntMatrix::IntMatrix(const IntMatrix & rhs) {
  if (rhs.numColumns < 0 || rhs.numRows < 0) {
    exit(EXIT_FAILURE);
  }
  else if (rhs.numRows == 0) {
    numRows = 0;
    numColumns = rhs.numColumns;
    rows = NULL;
  }
  else {
    numColumns = rhs.numColumns;
    numRows = rhs.numRows;
    rows = new IntArray *[rhs.numRows];
    for (int i = 0; i < rhs.numRows; i++) {
      rows[i] = new IntArray(rhs.getColumns());
      *(rows[i]) = *(rhs.rows[i]);
    }
  }
}

IntMatrix::~IntMatrix() {
  for (int i = 0; i < numRows; i++) {
    delete rows[i];
  }
  delete[] rows;
}
IntMatrix & IntMatrix::operator=(const IntMatrix & rhs) {
  if (rhs.numColumns < 0 || rhs.numRows < 0) {
    exit(EXIT_FAILURE);
  }

  if (*this == rhs) {
    return *this;
  }
  for (int i = 0; i < numRows; i++) {
    delete rows[i];
  }
  delete[] rows;
  numColumns = rhs.numColumns;
  numRows = rhs.numRows;
  rows = new IntArray *[rhs.numRows];
  for (int i = 0; i < rhs.numRows; i++) {
    rows[i] = new IntArray(rhs.numColumns);
    *rows[i] = *rhs.rows[i];
  }
  return *this;
}
int IntMatrix::getRows() const {
  return this->numRows;
}
int IntMatrix::getColumns() const {
  return this->numColumns;
}
const IntArray & IntMatrix::operator[](int index) const {
  assert(index >= 0 && index < numRows);
  return *rows[index];
}
IntArray & IntMatrix::operator[](int index) {
  assert(index >= 0 && index < numRows);
  return *rows[index];
}
bool IntMatrix::operator==(const IntMatrix & rhs) const {
  if (numRows == 0 && rhs.numRows == 0) {
    return true;
  }
  if (numRows != rhs.numRows) {
    return false;
  }
  if (numColumns != rhs.numColumns) {
    return false;
  }
  for (int i = 0; i < numRows; i++) {
    if (*rows[i] != *rhs.rows[i]) {
      return false;
    }
  }
  return true;
}

IntMatrix IntMatrix::operator+(const IntMatrix & rhs) const {
  assert(numRows == rhs.numRows);
  assert(numColumns == rhs.numColumns);
  if (numRows < 0 || numColumns < 0) {
    exit(EXIT_FAILURE);
  }

  IntMatrix a(numRows, numColumns);
  for (int i = 0; i < numRows; i++) {
    for (int j = 0; j < numColumns; j++) {
      a[i][j] = (*this)[i][j] + rhs[i][j];
    }
  }
  return a;
}
std::ostream & operator<<(std::ostream & s, const IntMatrix & rhs) {
  if (rhs.getRows() == 0) {
    s << "[ ]";
    return s;
  }
  s << "[ ";
  for (int i = 0; i < rhs.getRows() - 1; i++) {
    s << rhs[i] << ",\n";
  }
  s << rhs[rhs.getRows() - 1];
  s << " ]";
  return s;
}
