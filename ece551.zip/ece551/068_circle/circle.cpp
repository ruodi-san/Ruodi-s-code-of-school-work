#include "circle.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

Circle::Circle(Point p, const double r) : p(p), radius(r) {}
void Circle::move(double dx, double dy) {
  p.move(dx, dy);
}
double Circle::intersectionArea(const Circle & otherCircle) {
  if (p.distanceFrom(otherCircle.p) >= (radius + otherCircle.radius)) {
    return 0;
  }
  double d = p.distanceFrom(otherCircle.p);
  double r1 = radius;
  double r2 = otherCircle.radius;
  if (d <= abs(r1 - r2)) {
    return M_PI * pow((r1 > r2) ? r2 : r1, 2);
  }

  double s1 = r1 * r1 * acos((d * d + r1 * r1 - r2 * r2) / (2 * d * r1));
  double s2 = r2 * r2 * acos((d * d + r2 * r2 - r1 * r1) / (2 * d * r2));
  // double san = 1 / 2 * pow((r1 + r2 - d) * (r1 - r2 + d) * (r2 - r1 + d) * (r1 + r2 + d), 1 / 2);
  double ans = s1 + s2 - r1 * d * sin(s1 / (r1 * r1));
  return ans;
}
