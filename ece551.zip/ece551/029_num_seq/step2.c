// This file is for Step 2.
// You should do
//  Step 2 (A): write seq2
//  Step 2 (B): write main to test seq2
//  Step 2 (C): write sumSeq2
//  Step 2 (D): add test cases to main to test sumSeq2
//
// Be sure to #include any header files you need!
#include <stdio.h>
#include <stdlib.h>
int seq2(int x) {
  return x * x + 3 * x + 1;
}
int sumSeq2(int low, int high) {
  if (low >= high) {
    return 0;
  }
  else {
    int x;
    int sum = 0;
    for (x = low; x < high; x++) {
      sum = sum + seq2(x);
    }
    return sum;
  }
}
int main() {
  printf("seq2(%d)=%d\n", 1, seq2(1));
  printf("seq2(%d)=%d\n", 0, seq2(0));
  printf("seq2(%d)=%d\n", -1, seq2(-1));
  printf("seq2(%d)=%d\n", -4, seq2(-4));
  printf("seq2(%d)=%d\n", 8, seq2(8));
  printf("seq2(%d)=%d\n", -2, seq2(-2));
  printf("seq2(%d)=%d\n", 324, seq2(324));
  printf("seq2(%d)=%d\n", 32767, seq2(32767));
  printf("seq2(%d)=%d\n", -32768, seq2(-32768));
  printf("seq2(%d)=%d\n", -324, seq2(-324));

  printf("sumSeq2(%d, %d)=%d\n", 1, 5, sumSeq2(1, 5));
  printf("sumSeq2(%d, %d)=%d\n", 1, 1, sumSeq2(1, 1));
  printf("sumSeq2(%d, %d)=%d\n", 1, 0, sumSeq2(1, 0));
  printf("sumSeq2(%d, %d)=%d\n", 1, -5, sumSeq2(1, -5));
  printf("sumSeq2(%d, %d)=%d\n", -7, 5, sumSeq2(-7, 5));
  printf("sumSeq2(%d, %d)=%d\n", -7, -1, sumSeq2(-7, -1));
  printf("sumSeq2(%d, %d)=%d\n", -5, -5, sumSeq2(-5, -5));
  printf("sumSeq2(%d, %d)=%d\n", -1, -2, sumSeq2(-1, -2));
  printf("sumSeq2(%d, %d)=%d\n", 32760, 32767, sumSeq2(32760, 32767));
  printf("sumSeq2(%d, %d)=%d\n", -32768, -32760, sumSeq2(-32768, -32760));
  printf("sumSeq2(%d, %d)=%d\n", 0, 0, sumSeq2(0, 0));
  printf("sumSeq2(%d, %d)=%d\n", -6, -4, sumSeq2(-6, -4));

  return EXIT_SUCCESS;
}
