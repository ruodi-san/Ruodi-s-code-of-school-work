// This file is for Step 1.
// You should do
//  Step 1 (A): write seq1
//  Step 1 (B): write main to test seq1
//  Step 1 (C): write printSeq1Range
//  Step 1 (D): add test cases to main to test printSeq1Range
//
// Be sure to #include any header files you need!
#include <stdio.h>
#include <stdlib.h>
int seq1(int x) {
  return 4 * x - 3;
}
void printSeq1Range(int low, int high) {
  int x;
  if (low >= high) {
    printf("\n");
  }
  else {
    for (x = low; x < high - 1; x++) {
      printf("%d", seq1(x));
      printf(", ");
    }
    printf("%d", seq1(high - 1));
    printf("\n");
  }
}
int main() {
  int x;
  x = 0;
  printf("seq1(%d)=%d\n", x, seq1(x));
  x = 1;
  printf("seq1(%d)=%d\n", x, seq1(x));
  x = -1;
  printf("seq1(%d)=%d\n", x, seq1(x));
  x = 32767;
  printf("seq1(%d)=%d\n", x, seq1(x));
  x = -32768;
  printf("seq1(%d)=%d\n", x, seq1(x));
  x = 8195;
  printf("seq1(%d)=%d\n", x, seq1(x));
  printf("printSeq1Range(%d, %d)\n", 1, 3);
  printSeq1Range(1, 3);
  printf("printSeq1Range(%d, %d)\n", 2, 3);
  printSeq1Range(2, 3);
  printf("printSeq1Range(%d, %d)\n", 0, 0);
  printSeq1Range(0, 0);
  printf("printSeq1Range(%d, %d)\n", 3, 1);
  printSeq1Range(3, 1);
  printf("printSeq1Range(%d, %d)\n", 1, -1);
  printSeq1Range(1, -1);
  printf("printSeq1Range(%d, %d)\n", -1, 3);
  printSeq1Range(-1, 3);
  printf("printSeq1Range(%d, %d)\n", -5, -1);
  printSeq1Range(-5, -1);
  printf("printSeq1Range(%d, %d)\n", -4, -8);
  printSeq1Range(-4, -8);
  printf("printSeq1Range(%d, %d)\n", 3, -2);
  printSeq1Range(3, -2);
  printf("printSeq1Range(%d, %d)\n", -32768, -32764);
  printSeq1Range(-32768, -32764);
  printf("printSeq1Range(%d, %d)\n", 32760, 32767);
  printSeq1Range(32760, 32767);
  printf("printSeq1Range(%d, %d)\n", 8190, 8195);
  printSeq1Range(8190, 8195);

  return EXIT_SUCCESS;
}
