// This file is for Step 3.
// You should do
//  Step 3 (A): write seq3
//  Step 3 (B): write main to test seq3
//  Step 3 (C): write countEvenInSeq3Range
//  Step 3 (D): add test cases to main to test countEvenInSeq3Range
//
// Be sure to #include any header files you need!
#include <stdio.h>
#include <stdlib.h>
int seq3(int x, int y) {
  return x * y - 3 * x + 2 * y;
}
int countEvenInSeq3Range(int xLow, int xHi, int yLow, int yHi) {
  int sum = 0;
  int x, y;
  if (xLow >= xHi || yLow >= yHi) {
    return 0;
  }
  else {
    for (y = yLow; y < yHi; y++) {
      for (x = xLow; x < xHi; x++) {
        if ((seq3(x, y) % 2) == 0)
          sum += 1;
      }
    }
    return sum;
  }
}

int main() {
  printf("seq3(%d, %d)=%d\n", 0, 0, seq3(0, 0));
  printf("seq3(%d, %d)=%d\n", 0, 1, seq3(0, 1));
  printf("seq3(%d, %d)=%d\n", 2, 4, seq3(2, 4));
  printf("seq3(%d, %d)=%d\n", 1, 0, seq3(1, 0));
  printf("seq3(%d, %d)=%d\n", -2, -4, seq3(-2, -4));
  printf("seq3(%d, %d)=%d\n", 3, -6, seq3(3, -6));
  printf("seq3(%d, %d)=%d\n", -7, 2, seq3(-7, 2));
  printf("seq3(%d, %d)=%d\n", -2, 0, seq3(-2, 0));
  printf("seq3(%d, %d)=%d\n", 0, -4, seq3(0, -4));
  printf("seq3(%d, %d)=%d\n", 32767, 1, seq3(32767, 1));
  printf("seq3(%d, %d)=%d\n", -32768, 1, seq3(-32768, 1));
  printf("seq3(%d, %d)=%d\n", 1, 32767, seq3(1, 32767));
  printf("seq3(%d, %d)=%d\n", 1, -32768, seq3(1, -32768));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", 0, 0, 0, 0, countEvenInSeq3Range(0, 0, 0, 0));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", 0, 0, 1, 0, countEvenInSeq3Range(0, 0, 1, 0));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", 1, 0, 0, 0, countEvenInSeq3Range(1, 0, 0, 0));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", 1, 0, 1, 0, countEvenInSeq3Range(1, 0, 1, 0));
  printf(
      "countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", 0, -3, 0, 0, countEvenInSeq3Range(0, -3, 0, 0));
  printf(
      "countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", 0, 0, 0, -3, countEvenInSeq3Range(0, 0, 0, -3));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", 1, 2, 3, 4, countEvenInSeq3Range(1, 2, 3, 4));
  printf(
      "countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", -1, 2, 3, 7, countEvenInSeq3Range(-1, 2, 3, 7));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n",
         -4,
         1,
         -8,
         4,
         countEvenInSeq3Range(-4, 1, -8, 4));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n",
         -8,
         -6,
         -9,
         -7,
         countEvenInSeq3Range(-8, -6, -9, -7));
  printf(
      "countEvenInSeq3Range(%d, %d, %d, %d)=%d\n", 4, 9, -5, 3, countEvenInSeq3Range(4, 9, -5, 3));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n",
         32760,
         32767,
         0,
         1,
         countEvenInSeq3Range(32760, 32767, 0, 1));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n",
         0,
         4,
         32760,
         32767,
         countEvenInSeq3Range(0, 4, 32760, 32767));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n",
         -32768,
         -32760,
         0,
         4,
         countEvenInSeq3Range(-32768, -32760, 0, 4));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n",
         0,
         4,
         -32767,
         -32760,
         countEvenInSeq3Range(0, 4, -32767, -32760));
  printf("countEvenInSeq3Range(%d, %d, %d, %d)=%d\n",
         -32767,
         -32760,
         32760,
         32767,
         countEvenInSeq3Range(-32767, -32760, 32760, 32767));
  return EXIT_SUCCESS;
}
