
#include <assert.h>

#include "node.h"
Node * buildTree(uint64_t * counts) {
  assert(counts != NULL);
  priority_queue_t pq;
  int num = 0;
  for (int i = 0; i < 257; i++) {
    if (counts[i] != 0) {
      num++;
      pq.push(new Node(i, counts[i]));
    }
  }
  if (num == 0) {
    return NULL;
  }
  Node * pl = NULL;
  Node * pr = NULL;
  while (pq.size() > 1) {
    pl = pq.top();
    pq.pop();

    pr = pq.top();
    pq.pop();

    pq.push(new Node(pl, pr));
    pl = NULL;
    pr = NULL;
  }
  return pq.top();
}
