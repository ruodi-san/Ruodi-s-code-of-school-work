#include "election.h"
//include any other headers you need here...
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
state_t parseLine(const char * line) {
  state_t state;
  int count = 0;
  size_t q = 0;
  size_t i = 0;
  state.electoralVotes = 0;
  state.population = 0;
  for (size_t st = 0; st < 48; st++) {
    state.name[st] = 0;
  }
  if (line == NULL) {
    fprintf(stderr, "Invalid Input");
    exit(EXIT_FAILURE);
  }
  while (line[count] != '\0') {
    if (line[count] == ':') {
      q++;
    }
    count++;
  }
  if (q != 2) {
    fprintf(stderr, "invalid input");
    exit(EXIT_FAILURE);
  }

  while (line[i] != ':') {
    if ((line[i] < 'A' || (line[i] > 'Z' && line[i] < 'a') || line[i] > 'z') && (line[i] != ' ')) {
      fprintf(stderr, "name should be characters!");
      exit(EXIT_FAILURE);
    }
    state.name[i] = line[i];  //STEP 1: write me
    i++;
  }
  state.name[i] = '\0';
  if (i == 0) {
    fprintf(stderr, "No name input!");
    exit(EXIT_FAILURE);
  }
  size_t j = i + 1;
  size_t cp = 0;
  char population[cp + 1];

  while (line[j] != ':') {
    if (line[j] < '0' || line[j] > '9') {
      fprintf(stderr, "population shuold be a number!");
      exit(EXIT_FAILURE);
    }
    j++;
    cp++;
  }
  for (size_t a = 0; a < cp; a++) {
    population[a] = line[i + 1 + a];
  }
  population[cp] = '\0';
  state.population = (uint64_t)atoi(population);
  if (cp == 0) {
    fprintf(stderr, "No population input!");
    exit(EXIT_FAILURE);
  }

  size_t k = j + 1;
  size_t cv = 0;
  char votes[cv + 1];
  while (line[k] != '\0') {
    if (line[k] < '0' || line[k] > '9') {
      fprintf(stderr, "electoralVotes should be a number!");
      exit(EXIT_FAILURE);
    }

    k++;
    cv++;
  }

  for (size_t a = 0; a < cv; a++) {
    votes[a] = line[j + 1 + a];
  }
  votes[cv] = '\0';
  state.electoralVotes = (unsigned int)atoi(votes);

  return (state);
}
unsigned int countElectoralVotes(state_t * stateData, uint64_t * voteCounts, size_t nStates) {
  int vote = 0;
  int sum = 0;
  if (stateData == NULL || voteCounts == NULL || nStates == 0) {
    fprintf(stderr, "Invalid input!");
    exit(EXIT_FAILURE);
  }
  for (size_t i = 0; i < nStates; i++) {
    if (voteCounts[i] > stateData[i].population) {
      fprintf(stderr, "Invalid votecounts!");
      exit(EXIT_FAILURE);
    }
  }
  for (size_t i = 0; i < nStates; i++) {
    if (((double)voteCounts[i] / (double)stateData[i].population) > 0.5) {
      vote = stateData[i].electoralVotes;
    }
    else {
      vote = 0;
    }
    sum = sum + vote;  //STEP 2: write me
  }

  return sum;
}
void printRecounts(state_t * stateData, uint64_t * voteCounts, size_t nStates) {
  if (stateData == NULL || voteCounts == NULL || nStates == 0) {
    fprintf(stderr, "Invalid input!");
    exit(EXIT_FAILURE);
  }
  for (size_t i = 0; i < nStates; i++) {
    if (voteCounts[i] > stateData[i].population) {
      fprintf(stderr, "Invalid votecounts!");
      exit(EXIT_FAILURE);
    }
  }
  double per;
  for (size_t i = 0; i < nStates; i++) {
    if ((((double)voteCounts[i] / (double)stateData[i].population) >= 0.495) &&
        (((double)voteCounts[i] / (double)stateData[i].population) <= 0.505)) {
      per = (double)voteCounts[i] / (double)stateData[i].population;
      printf(
          "%s requires a recount (Candidate A has %.2f%% of the vote)\n", stateData[i].name, per);
      //STEP 3: write me
    }
  }
}
void printLargestWin(state_t * stateData, uint64_t * voteCounts, size_t nStates) {
  if (stateData == NULL || voteCounts == NULL || nStates == 0) {
    fprintf(stderr, "Invalid input!");
    exit(EXIT_FAILURE);
  }
  for (size_t i = 0; i < nStates; i++) {
    if (voteCounts[i] > stateData[i].population) {
      fprintf(stderr, "Invalid votecounts!");
      exit(EXIT_FAILURE);
    }
  }
  double m[nStates];
  size_t max = 0;
  for (size_t i = 0; i < nStates; i++) {
    m[i] = (double)voteCounts[i] / (double)stateData[i].population * 100;
  }
  for (size_t i = 1; i < nStates; i++) {
    if (m[i] > m[max]) {
      max = i;
    }
  }
  printf("Candidate A won %s with %.2f%% of the vote\n", stateData[max].name, m[max]);
  //STEP 4: write me
}
