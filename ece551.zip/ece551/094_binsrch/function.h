#ifndef __FUNCTION_H__
#define __FUNCTION_H__

template<typename R, typename A>
class Function
{
 public:
  virtual R invoke(A arg) = 0;
  virtual ~Function() {}
};
int binarySearchForZero(Function<int, int> * f, int low, int high) {
  int half = (low + high) / 2;
  while ((high - low) > 1) {
    int j = f->invoke(half);
    if (j > 0) {
      high = half;
    }
    else if (j == 0) {
      return half;
    }
    else {
      low = half;
    }
    half = (low + high) / 2;
    //std::cout << half;
  }
  if (high - low == 1) {
    return low;
  }
  return half;
}
#endif
