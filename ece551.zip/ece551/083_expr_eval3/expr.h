#include <iostream>
#include <sstream>
#include <string>
using namespace std;
class Expression
{
 protected:
  string ans;
  long output;

 public:
  virtual std::string toString() const = 0;
  virtual ~Expression() {}
  virtual long evaluate() const = 0;
};
class NumExpression : public Expression
{
 private:
  long num;
  //  long n;

 public:
  NumExpression(long input) : num(input) {
    stringstream ss;
    ss << num;
    ans = ss.str();
    // ss >> n;
    output = num;
  }

  virtual std::string toString() const { return ans; }
  virtual long evaluate() const { return output; }
  virtual ~NumExpression() {}
};
class operators : public Expression
{
 protected:
  string alhs;
  string arhs;
  long a;
  long b;

 public:
  operators(Expression * lhs, Expression * rhs) :
      alhs("(" + lhs->toString()),
      arhs(rhs->toString() + ")"),
      a(lhs->evaluate()),
      b(rhs->evaluate()) {
    /*    stringstream iss;
    iss << lhs;
    iss >> a;
    iss.clear();
    iss << rhs;
    iss >> b;
    iss.clear();*/

    delete lhs;
    delete rhs;
  }
  virtual long evaluate() const { return output; }
  virtual string toString() const { return ans; }
  virtual ~operators() {}
};
/*class Evaluate : public Expression
{
 protected:
  long a;
  long b;
public:
   Evaluate(Expression * lhs, Expression * rhs) {
     stringstream iss;
     iss<<lhs;
     iss >> a;
    iss.clear();
    iss << rhs;
    iss >> b;
    iss.clear();
    delete lhs;
    delete rhs;
  }
  virtual long evaluate const(){
    return output;}
    };*/
class PlusExpression : public operators
{
 public:
  PlusExpression(Expression * lhs, Expression * rhs) : operators(lhs, rhs) {
    ans = alhs + "+" + arhs;
    output = a + b;
  }

  virtual ~PlusExpression() {}
};
class MinusExpression : public operators
{
 public:
  MinusExpression(Expression * lhs, Expression * rhs) : operators(lhs, rhs) {
    ans = alhs + "-" + arhs;

    output = a - b;
  }
  virtual ~MinusExpression() {}
};

class TimesExpression : public operators
{
 public:
  TimesExpression(Expression * lhs, Expression * rhs) : operators(lhs, rhs) {
    ans = alhs + "*" + arhs;

    output = a * b;
  }
  virtual ~TimesExpression() {}
};
class DivExpression : public operators
{
 public:
  DivExpression(Expression * lhs, Expression * rhs) : operators(lhs, rhs) {
    ans = alhs + "/" + arhs;

    output = a / b;
  }
  virtual ~DivExpression() {}
};
