#include <cstdlib>
#include <iostream>
#include <string>

#include "bstset.h"
#include "set.h"

using namespace std;

int main() {
  BstSet<int> Set;
  Set.add(2);
  Set.printtest();
  Set.add(4);
  Set.printtest();
  Set.add(70);
  Set.printtest();
  Set.add(6);
  Set.printtest();
  Set.remove(2);
  Set.printtest();
  cout << Set.contains(4) << endl;
  Set.remove(4);
  Set.printtest();
  Set.remove(-1);
  Set.printtest();
  cout << Set.contains(4) << endl;
  cout << Set.contains(6) << endl;

  return EXIT_SUCCESS;
}
