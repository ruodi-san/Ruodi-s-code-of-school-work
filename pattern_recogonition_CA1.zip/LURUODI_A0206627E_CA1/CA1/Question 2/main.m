%the output is error_train and error test, see workspace 
%init
close all;clear;clc;

%load dataset
load('spamData.mat');

%log-transform
xtrain=log(Xtrain+0.1);
xtest=log(Xtest+0.1);
[train_size,D]=size(xtrain); test_size=size(xtest,1);
%prior probility
lambda_1=sum(ytrain)/train_size;%rate of spam
lambda_0=1-lambda_1;%rate of non_spam

%calculation mu&sigma both y=1&y=0
mu_mean_y1=mean(xtrain(ytrain==1,:));
mu_mean_y0=mean(xtrain(ytrain==0,:));
sigma_std_y1=std(xtrain(ytrain==1,:));
sigma_std_y0=std(xtrain(ytrain==0,:));
%inicialize labels
Estimate_ytrain = zeros(train_size,1);
Estimate_ytest = zeros(test_size,1);

%naive bayes
%train 
for m=1:train_size
    %plug in
    train_log_y1=log(lambda_1);
    train_log_y0=log(lambda_0);  
    for n=1:D
        p_y1=normpdf(xtrain(m,n),mu_mean_y1(1,n),sigma_std_y1(1,n));
        p_y0=normpdf(xtrain(m,n),mu_mean_y0(1,n),sigma_std_y0(1,n));
        train_log_y1=train_log_y1+log(p_y1);
        train_log_y0=train_log_y0+log(p_y0);         
    end
    Estimate_ytrain(m)=(train_log_y1>train_log_y0);
    error_train=sum(abs(Estimate_ytrain-ytrain))/train_size;
end
%test
for m=1:test_size
    %plug in
    test_log_y1=log(lambda_1);
    test_log_y0=log(lambda_0);  
    for n=1:D
        p_y1=normpdf(xtest(m,n),mu_mean_y1(1,n),sigma_std_y1(1,n));
        p_y0=normpdf(xtest(m,n),mu_mean_y0(1,n),sigma_std_y0(1,n));
        test_log_y1=test_log_y1+log(p_y1);
        test_log_y0=test_log_y0+log(p_y0);         
    end
    Estimate_ytest(m)=(test_log_y1>test_log_y0);
    error_test=sum(abs(Estimate_ytest-ytest))/test_size;
end
