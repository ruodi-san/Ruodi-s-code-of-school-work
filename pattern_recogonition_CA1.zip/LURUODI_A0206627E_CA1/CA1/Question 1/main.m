%init
close all;clear;clc;
load('spamData.mat');
%data processing
Xtrain_temp = zeros(size(Xtrain));Xtest_temp = zeros(size(Xtest));
Xtrain_temp(Xtrain == 0) = 0;Xtrain_temp(Xtrain ~= 0) = 1;
Xtest_temp(Xtest == 0) = 0;Xtest_temp(Xtest ~= 0) = 1;
Xtrain=Xtrain_temp; Xtest=Xtest_temp; clear Xtrain_temp; clear Xtest_temp;
%setting alpha
alpha=0:0.5:100;
N=length(alpha);
%create a vector of error of train and test with dimension of length alpha
error_train=zeros(1,N);
error_test=zeros(1,N);
%naive bayes
for i = 1:size(alpha,2) 
    [error_train(i),error_test(i)]=learning(Xtrain,ytrain,Xtest,ytest,alpha(i));
end
%plot figure
figure(1);
plot(alpha,error_train,'-.','LineWidth',1.5);
hold on;
plot(alpha,error_test,'-.','LineWidth',1.5);
hold on;

legend('training error','test error');
title('training and test error rates versus alpha');
xlabel('alpha');
ylabel('error rate');