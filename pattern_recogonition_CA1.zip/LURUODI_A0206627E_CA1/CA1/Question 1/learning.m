function [error_train, error_test] = learning(Xtrain, ytrain, Xtest, ytest, a)

%get the train size, test size and dimensions
[train_size,D]=size(Xtrain); test_size=size(Xtest,1);

lambda_1=sum(ytrain)/train_size;% prior probobility for training
lambda_0=1-lambda_1;

%data preparing
%calculate P(x=1|y=1)&P(x=1|y=0)&P(x=0|y=1)&P(x=0|y=0)
x1y1 = zeros(1,D);
x0y1 = zeros(1,D);
x1y0 = zeros(1,D);
x0y0 = zeros(1,D);

%calculate each circumstances' number
N_1 = sum(ytrain);    %y=1 in Xtrain
N_0 = train_size-N_1;   %y=0 in Xtest
for i = 1:D    
    x1y1(i) = sum(Xtrain((ytrain == 1),i)); %x=1 & y=1
    x0y1(i)=N_1-x1y1(i); %x=0 & y=1
    x1y0(i) = sum(Xtrain((ytrain == 0),i)); %x=1 & y=0
    x0y0(i)=N_0-x1y0(i); % x=0 & y=0
end
%inicialize estimate ytrain and ytest given data
Estimate_ytrain = zeros(train_size,1);
Estimate_ytest = zeros(test_size,1);
for m=1:train_size
    train_log_y1=log(lambda_1);
    train_log_y0=log(lambda_0);
     
    for n=1:D
        if Xtrain(m,n)==1
            log_y1=log((x1y1(n)+a)/(N_1+2*a));%y=1&x=1
            log_y0=log((x1y0(n)+a)/(N_0+2*a));%y=0&x=1
        else
            log_y1=log((x0y1(n)+a)/(N_1+2*a));%y=1&x=0
            log_y0=log((x0y0(n)+a)/(N_0+2*a));%y=0&x=0
        end
        train_log_y1=train_log_y1+log_y1;
        train_log_y0=train_log_y0+log_y0;
    end
        
    %calculate error rate
    Estimate_ytrain(m)=(train_log_y1>train_log_y0);
    error_train=sum(abs(Estimate_ytrain-ytrain))/train_size;
end

%test dataset
for m=1:test_size 
    test_log_y1=log(lambda_1);
    test_log_y0=log(lambda_0);
    for n=1:D
        if Xtest(m,n)==1
            %Laplacian correction
            log_y1=log((x1y1(n)+a)/(N_1+2*a));%y=1&x=1
            log_y0=log((x1y0(n)+a)/(N_0+2*a));%y=0&x=1
        else
            log_y1=log((x0y1(n)+a)/(N_1+2*a));%y=1&x=0
            log_y0=log((x0y0(n)+a)/(N_0+2*a));%y=0&x=0
        end
        test_log_y1=test_log_y1+log_y1;
        test_log_y0=test_log_y0+log_y0;
    end
    %calculate error rate
    Estimate_ytest(m,1)=(test_log_y1>test_log_y0);
    error_test=sum(abs(Estimate_ytest-ytest))/test_size;
end

end
