function [train_error, test_error] = knn(Xtrain,ytrain,Xtest,ytest,k)
train_num = size(Xtrain,1); % number of training data set
test_num  = size(Xtest,1);  % number of test data set
train_label=zeros(train_num,1);
test_label = zeros(test_num,1);
distance = zeros(train_num,1);

% compute distances between train data and all training data
for i = 1:train_num
    test = Xtrain(i,:);
    
    for j = 1:train_num
        train = Xtrain(j,:);
        d = test-train;
        distance(j,1) = norm(d,2);
    end
    
    [distsort,inds] = sort(distance); % sort distances
    knear = distsort(1:k,1); 
    
    for ii = 1:k 
        if (inds(ii,1) ~= ii)
            knear(ii,1) = ytrain(inds(ii,1),1);
        else
            knear(ii,1) = ytrain(ii,1);
        end
    end
    
    class0_num = size(find(knear(:,1) == 0),1);  
    class1_num = size(find(knear(:,1) == 1),1); 
  
    if (max([class0_num,class1_num]) == class0_num)
        train_label(i,1) = 0;
    else 
        train_label(i,1) = 1;                  
    end

end

train_error = (train_label ~= ytrain);

% compute distances between test data and all training data
for i = 1:test_num
    test = Xtest(i,:);
    
    for j = 1:train_num
        train = Xtrain(j,:);
        d = test-train;
        distance(j,1) = norm(d,2);
    end
    
    [distsort,inds] = sort(distance); % sort distances
    knear = distsort(1:k,1); 
    
    for ii = 1:k 
        if (inds(ii,1) ~= ii)
            knear(ii,1) = ytrain(inds(ii,1),1);
        else
            knear(ii,1) = ytrain(ii,1);
        end
    end
    
    class0_num = size(find(knear(:,1) == 0),1);  
    class1_num = size(find(knear(:,1) == 1),1); 
  
    if (max([class0_num,class1_num]) == class0_num)
        test_label(i,1) = 0;
    else 
        test_label(i,1) = 1;                  
    end
end 
test_error = (test_label ~= ytest);
