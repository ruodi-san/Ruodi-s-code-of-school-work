clear all; close all; clc
load('spamData.mat');
%data processing
xtrain=log(Xtrain+0.1);
xtest=log(Xtest+0.1);

K=[1:10 15:5:100];
error_train=zeros(size(Xtrain,1),length(K));
error_test=zeros(size(Xtest,1),length(K));

error_train_rate=zeros(length(K),1);
error_test_rate=zeros(length(K),1);
for i=1:length(K)
    [error_train(:,i),error_test(:,i)]=knn(xtrain,ytrain,xtest,ytest,K(i));
    
end
for j=1:length(K)
    error_train_rate(j)=sum(error_train(:,j))/size(Xtrain,1);
    error_test_rate(j)=sum(error_test(:,j))/size(Xtest,1);
end
figure(1);
plot(K,error_train_rate,'--','LineWidth',1.5);
hold on;
plot(K,error_test_rate,'-.','LineWidth',1.5);
hold on;
legend('training error','test error');
title('training and test error rates versus K');
xlabel('K');
ylabel('error rate');



