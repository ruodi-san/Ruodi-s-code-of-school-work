function [train_label,test_label]=Newtontraining(xtrain,ytrain,xtest,l,convergence)

    w=zeros(size(xtrain,2),1); %D+1 by 1
    D=size(xtrain,2)-1;
    w0=w(2:end);% D by 1
    mu_train=sigm(xtrain*w); % N+1 by 1
    g=xtrain'*(mu_train-ytrain);
    %inicialize I
    I=[zeros(1,D+1);zeros(D,1) eye(D)];
    %compute s
    s=diag(mu_train.*(1-mu_train));
    %solve H
    H=xtrain'*s*xtrain;
    NLL=-ytrain'*log(mu_train)-(1-ytrain)'*log(1-mu_train);
    g(2:end)=g(2:end)+l*w0;%g_reg
    H=H+l*I;%H_reg
    NLL_reg=NLL+0.5*l*(w0.'*w0);
    w=w-pinv(H)*g;%update w
    e=1;
   % training loop
    while (e>convergence)
        NLL_t=NLL_reg;%cave last NLL to compare
        w0=w(2:end);%w0 is w without first element
        mu_train=sigm(xtrain*w);
        g=xtrain'*(mu_train-ytrain);
        s=diag(mu_train.*(1-mu_train));
        H=xtrain.'*s*xtrain;
        NLL=-ytrain'*log(mu_train)-(1-ytrain)'*log(1-mu_train);
        g(2:end)=g(2:end)+l*w0;%g_reg
        H=H+l*I;%H_reg
        NLL_reg=NLL+0.5*l*(w0.'*w0);
        w=w-pinv(H)*g;%update w
        e=abs(NLL_reg-NLL_t);%compare distance
    end
    train_label=(mu_train>0.5);%mu_train>0.5 so class=1

    %test dataset
    mu_test=sigm(xtest*w);% w has been updated after training
    test_label=(mu_test>0.5);
end
   

