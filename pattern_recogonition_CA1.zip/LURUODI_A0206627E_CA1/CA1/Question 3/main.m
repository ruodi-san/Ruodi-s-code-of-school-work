close all;clear;clc;

%load dataset
load('spamData.mat');

%log-transform
xtrain=log(Xtrain+0.1);
xtest=log(Xtest+0.1);
[train_size,D]=size(xtrain); test_size=size(xtest,1);

%inicialize x(D+1)
xtrain=[ones(train_size,1) xtrain];% N+1 by D+1
xtest=[ones(test_size,1) xtest];%N+1 by D+1
w=zeros(D+1,1); %D+1 by 1
%initialize I(D+1)*(D+1)
I=[zeros(1,D+1);zeros(D,1) eye(D)];
%record ytrain and ytest given convergence
convergence=1e-6;
train_label=zeros(1,train_size);
test_label=zeros(1,test_size);

lambda=[1:10 15:5:100];%regulation parameter
error_rate_train=zeros(1,length(lambda));
error_rate_test=zeros(1,length(lambda));

%Newton's method with l2 Regulation
for i=1:length(lambda)
    [train_label,test_label]=Newtontraining(xtrain,ytrain,xtest,lambda(i),convergence);
    error_rate_train(i)=sum(abs(train_label-ytrain))/train_size;
    error_rate_test(i)=sum(abs(test_label-ytest))/test_size;
end

%plot figure
figure(1);
plot(lambda,error_rate_train,'--','LineWidth',1.5);
hold on;
plot(lambda,error_rate_test,'-.','LineWidth',1.5);
hold on;
legend('training error','test error');
title('training and test error rates versus lambda');
xlabel('lambda');
ylabel('error rate');